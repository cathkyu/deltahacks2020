# Color Recognition API

Color classifying by K-Nearest Neighbors Machine Learning Classifier which is trained by R, G, B Color Histogram. It can classify White, Black, Red, Green, Blue, Orange, Yellow and Violet. 

For more detailed information, see the orginal repo of the [Color Recognition project](https://github.com/ahmetozlu/color_recognition).
